// middleware/auth.js
import jwt from 'jsonwebtoken';

/**
 * Middleware pour vérifier le JWT d'authentification
 */
// middleware/auth.js
export function authenticateToken(req, res, next) {
  console.log("=== MIDDLEWARE AUTHENTICATE TOKEN ===");
  
  // Récupérer le header d'autorisation
  const authHeader = req.headers['authorization'];
  console.log("Headers d'autorisation:", authHeader);
  
  const token = authHeader && authHeader.split(' ')[1];
  console.log("Token extrait:", token ? "Présent" : "Absent");
  
  if (!token) {
    console.log("Erreur: Token manquant");
    return res.status(401).json({ message: 'Authentification requise' });
  }
  
  try {
    // Vérifier le token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log("Token décodé:", decoded);
    
    // Vérifier spécifiquement la présence de userId
    if (!decoded.userId) {
      console.log("Erreur: Token valide mais sans userId");
      return res.status(403).json({ message: 'Token invalide - userId manquant' });
    }
    
    req.user = decoded;
    console.log("Authentification réussie pour userId:", decoded.userId);
    next();
  } catch (error) {
    console.error("Erreur de vérification du token:", error);
    return res.status(403).json({ message: 'Token invalide ou expiré' });
  }
}