// services/repositoryManager.js
import path from 'path';
import { promises as fs } from 'fs';
import os from 'os';
import { execSync } from 'child_process';

/**
 * Télécharge un dépôt GitHub
 * @param {Object} octokit - Instance Octokit authentifiée
 * @param {string} owner - Propriétaire du dépôt
 * @param {string} repo - Nom du dépôt
 * @returns {string} Chemin local vers le dépôt téléchargé
 */
export async function downloadRepository(octokit, owner, repo) {
  try {
    // Crée un dossier temporaire
    const tempDir = path.join(os.tmpdir(), `github-${owner}-${repo}-${Date.now()}`);
    await fs.mkdir(tempDir, { recursive: true });
    
    // Récupère l'URL du dépôt
    const { data } = await octokit.repos.get({ owner, repo });
    const cloneUrl = data.clone_url;
    
    // Clone le dépôt (nécessite Git installé sur le serveur)
    console.log(`Clonage du dépôt: ${cloneUrl} dans ${tempDir}`);
    execSync(`git clone ${cloneUrl} ${tempDir}`, { stdio: 'inherit' });
    
    return tempDir;
  } catch (error) {
    console.error(`Erreur lors du téléchargement du dépôt: ${error.message}`);
    throw error;
  }
}