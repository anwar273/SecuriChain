// services/scraperService.js
import axios from 'axios';
import VulnerabilityDatabase from '../models/VulnerabilityDatabase.js';

/**
 * Service pour scraper les bases de données de vulnérabilités
 */
export const scraperService = {
  /**
   * Récupère les vulnérabilités pertinentes pour un projet
   * @param {string} language - Langage principal du projet
   * @param {Array} dependencies - Dépendances du projet
   * @returns {Array} Vulnérabilités pertinentes
   */
  getRelevantVulnerabilities: async function(language, dependencies) {
    try {
      // Chercher d'abord dans notre base de données locale
      const localVulnerabilities = await VulnerabilityDatabase.find({
        programmingLanguages: language
      }).lean();
      
      // Récupérer les vulnérabilités depuis les APIs externes
      const externalVulnerabilities = await this.fetchFromExternalSources(language, dependencies);
      
      // Combiner et formater les résultats
      const allVulnerabilities = [
        ...localVulnerabilities.map(this.formatLocalVulnerability),
        ...externalVulnerabilities
      ];
      
      return allVulnerabilities;
    } catch (error) {
      console.error('Erreur lors de la récupération des vulnérabilités:', error);
      return [];
    }
  },
  
  /**
   * Récupère les vulnérabilités depuis des sources externes
   * @param {string} language - Langage principal
   * @param {Array} dependencies - Dépendances
   * @returns {Array} Vulnérabilités externes
   */
  fetchFromExternalSources: async function(language, dependencies) {
    // Cette fonction serait implémentée pour interagir avec des APIs comme:
    // - NVD (National Vulnerability Database)
    // - CVE Details
    // - GitHub Security Advisories
    // - Snyk Vulnerability DB
    
    // Pour cet exemple, nous utilisons des données simulées
    return this.getSimulatedVulnerabilities(language);
  },
  
  /**
   * Formate une vulnérabilité locale pour l'analyse
   * @param {Object} vulnerability - Vulnérabilité en base de données
   * @returns {Object} Vulnérabilité formatée
   */
  formatLocalVulnerability: function(vulnerability) {
    return {
      title: vulnerability.title,
      description: vulnerability.description,
      severity: vulnerability.severity,
      cveId: vulnerability.cveId,
      type: vulnerability.cweIds?.length > 0 ? vulnerability.cweIds[0] : 'Unknown',
      signature: vulnerability.description.substring(0, 50).toLowerCase(),
      mitigation: vulnerability.mitigation
    };
  },
  
  /**
   * Génère des vulnérabilités simulées pour les tests
   * @param {string} language - Langage de programmation
   * @returns {Array} Vulnérabilités simulées
   */
  getSimulatedVulnerabilities: function(language) {
    const vulnerabilitiesByLanguage = {
      'JavaScript': [
        {
          title: 'Prototype Pollution',
          description: 'Vulnérabilité permettant de modifier le prototype des objets JavaScript, pouvant mener à l\'exécution de code arbitraire.',
          severity: 'high',
          cveId: 'CVE-2022-12345',
          type: 'CWE-1321',
          signature: 'Object.prototype',
          mitigation: 'Utiliser Object.freeze() sur Object.prototype ou éviter les opérations récursives sur les objets non validés.'
        },
        {
          title: 'ReDoS (Regular Expression Denial of Service)',
          description: 'Expression régulière vulnérable à une attaque par déni de service due à une complexité exponentielle.',
          severity: 'medium',
          cveId: 'CVE-2023-67890',
          type: 'CWE-1333',
          signature: '(a+)+',
          mitigation: 'Éviter les expressions régulières avec retour en arrière exponentiel ou limiter la longueur des entrées.'
        }
      ],
      'Python': [
        {
          title: 'Format String Vulnerability',
          description: 'Vulnérabilité permettant d\'accéder à des données non autorisées via le formatage de chaînes.',
          severity: 'high',
          cveId: 'CVE-2022-24567',
          type: 'CWE-134',
          signature: 'format(',
          mitigation: 'Utiliser des littéraux de format avec des positions nommées plutôt que des entrées utilisateur directes.'
        }
      ],
      'PHP': [
        {
          title: 'Remote Code Execution in eval()',
          description: 'Utilisation non sécurisée de la fonction eval() permettant l\'exécution de code arbitraire.',
          severity: 'critical',
          cveId: 'CVE-2022-98765',
          type: 'CWE-95',
          signature: 'eval(',
          mitigation: 'Ne jamais utiliser eval() avec des entrées utilisateur ou utiliser des alternatives plus sûres.'
        }
      ]
    };
    
    return vulnerabilitiesByLanguage[language] || [];
  }
};