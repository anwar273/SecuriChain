// services/analysisPipeline.js
import { Octokit } from '@octokit/rest';
import User from '../models/User.js';
import SecurityAnalysis from '../models/SecurityAnalysis.js';
import VulnerabilityDatabase from '../models/VulnerabilityDatabase.js';
import { selectOptimalModels } from './modelSelector.js';
import { downloadRepository } from './repositoryManager.js';
import { scanVulnerabilities } from './vulnerabilityScanner.js';
import { scraperService } from './scraperService.js';
import { calculateSecurityScore } from './securityScoreCalculator.js';

/**
 * Orchestre l'ensemble du pipeline d'analyse de sécurité
 * @param {string} analysisId - ID de l'analyse en cours
 * @param {string} userId - ID de l'utilisateur
 * @param {Object} repository - Objet repository
 */
export async function startAnalysisPipeline(analysisId, userId, repository) {
  try {
    // Mettre à jour le statut de l'analyse
    await updateAnalysisStatus(analysisId, 'in-progress');
    
    // Récupérer l'utilisateur et son token GitHub
    const user = await User.findById(userId);
    if (!user || !user.githubToken) {
      throw new Error('Token GitHub non disponible');
    }
    
    // Initialiser l'API GitHub
    const octokit = new Octokit({ auth: user.githubToken });
    
    // 1. Télécharger le dépôt
    console.log(`Téléchargement du dépôt ${repository.name}...`);
    const repoPath = await downloadRepository(octokit, repository.owner, repository.name);
    
    // 2. Analyser la structure du projet et le langage principal
    console.log(`Analyse de la structure du projet...`);
    const projectStructure = await analyzeProjectStructure(repoPath, repository.primaryLanguage);
    
    // 3. Sélectionner les modèles optimaux pour l'analyse
    console.log(`Sélection des modèles d'IA...`);
    const selectedModels = await selectOptimalModels(projectStructure);
    
    // 4. Scraper les bases de données de vulnérabilités pertinentes
    console.log(`Récupération des vulnérabilités connues...`);
    const relevantVulnerabilities = await scraperService.getRelevantVulnerabilities(
      repository.primaryLanguage, 
      projectStructure.dependencies
    );
    
    // 5. Lancer l'analyse de sécurité
    console.log(`Lancement de l'analyse de sécurité...`);
    const startTime = Date.now();
    const vulnerabilities = await scanVulnerabilities(
      repoPath,
      projectStructure,
      selectedModels,
      relevantVulnerabilities
    );
    const executionTime = (Date.now() - startTime) / 1000;
    
    // 6. Calculer le score de sécurité
    const securityScore = calculateSecurityScore(vulnerabilities, projectStructure);
    
    // 7. Générer le résumé
    const summary = generateSummary(vulnerabilities, securityScore, projectStructure);
    
    // 8. Mettre à jour l'analyse avec les résultats
    await SecurityAnalysis.findByIdAndUpdate(analysisId, {
      status: 'completed',
      completedAt: new Date(),
      vulnerabilities,
      securityScore,
      usedModels: selectedModels.map(model => ({
        name: model.name,
        version: model.version,
        purpose: model.purpose
      })),
      summary,
      executionTimeSeconds: executionTime
    });
    
    console.log(`Analyse terminée avec ${vulnerabilities.length} vulnérabilités détectées`);
    
  } catch (error) {
    console.error('Erreur lors de l\'analyse:', error);
    
    // En cas d'erreur, mettre à jour le statut de l'analyse
    await SecurityAnalysis.findByIdAndUpdate(analysisId, {
      status: 'failed',
      completedAt: new Date(),
      errorDetails: error.message
    });
  }
}

/**
 * Met à jour le statut d'une analyse
 * @param {string} analysisId - ID de l'analyse
 * @param {string} status - Nouveau statut
 */
async function updateAnalysisStatus(analysisId, status) {
  await SecurityAnalysis.findByIdAndUpdate(analysisId, { status });
}

/**
 * Analyse la structure du projet
 * @param {string} repoPath - Chemin vers le dépôt local
 * @param {string} primaryLanguage - Langage principal
 * @returns {Object} Structure du projet
 */
async function analyzeProjectStructure(repoPath, primaryLanguage) {
  // Implémentation simplifiée pour l'exemple
  return {
    primaryLanguage,
    allLanguages: [primaryLanguage], // À étendre avec une détection réelle
    fileCount: 0,
    dependencies: [],
    frameworks: [],
    complexity: 'medium',
    hasTests: false,
    hasCICD: false,
    securityFeatures: []
  };
}

/**
 * Génère un résumé de l'analyse
 * @param {Array} vulnerabilities - Liste des vulnérabilités
 * @param {number} securityScore - Score de sécurité
 * @param {Object} projectStructure - Structure du projet
 * @returns {string} Résumé de l'analyse
 */
function generateSummary(vulnerabilities, securityScore, projectStructure) {
  const criticalCount = vulnerabilities.filter(v => v.severity === 'critical').length;
  const highCount = vulnerabilities.filter(v => v.severity === 'high').length;
  const mediumCount = vulnerabilities.filter(v => v.severity === 'medium').length;
  const lowCount = vulnerabilities.filter(v => v.severity === 'low').length;
  
  let riskLevel = 'faible';
  if (criticalCount > 0 || highCount > 3) {
    riskLevel = 'élevé';
  } else if (highCount > 0 || mediumCount > 5) {
    riskLevel = 'modéré';
  }
  
  return `
    L'analyse de sécurité a détecté ${vulnerabilities.length} vulnérabilités potentielles:
    - ${criticalCount} critiques
    - ${highCount} élevées
    - ${mediumCount} moyennes
    - ${lowCount} faibles
    
    Le score de sécurité global est de ${securityScore}/100, ce qui représente un niveau de risque ${riskLevel}.
    
    Principales recommandations:
    ${generateTopRecommendations(vulnerabilities)}
  `;
}

/**
 * Génère les principales recommandations basées sur les vulnérabilités
 * @param {Array} vulnerabilities - Liste des vulnérabilités
 * @returns {string} Recommandations
 */
function generateTopRecommendations(vulnerabilities) {
  // Groupe les recommandations par type et prend les plus importantes
  const recommendationsByType = {};
  
  vulnerabilities.forEach(vuln => {
    if (!recommendationsByType[vuln.vulnerabilityType]) {
      recommendationsByType[vuln.vulnerabilityType] = {
        severity: getSeverityValue(vuln.severity),
        recommendation: vuln.recommendation
      };
    } else if (getSeverityValue(vuln.severity) > recommendationsByType[vuln.vulnerabilityType].severity) {
      recommendationsByType[vuln.vulnerabilityType] = {
        severity: getSeverityValue(vuln.severity),
        recommendation: vuln.recommendation
      };
    }
  });
  
  // Trier par sévérité et prendre les 3 plus importantes
  const topRecommendations = Object.entries(recommendationsByType)
    .sort((a, b) => b[1].severity - a[1].severity)
    .slice(0, 3)
    .map(([type, { recommendation }]) => `- ${recommendation}`);
  
  return topRecommendations.join('\n    ');
}

/**
 * Convertit la sévérité en valeur numérique pour le tri
 * @param {string} severity - Niveau de sévérité
 * @returns {number} Valeur numérique
 */
function getSeverityValue(severity) {
  const values = {
    'critical': 4,
    'high': 3,
    'medium': 2,
    'low': 1
  };
  return values[severity] || 0;
}

// Notez que nous exportons uniquement startAnalysisPipeline comme export nommé
// Les autres fonctions sont privées à ce module