// services/securityScoreCalculator.js

/**
 * Calcule un score de sécurité global pour le projet
 * @param {Array} vulnerabilities - Liste des vulnérabilités
 * @param {Object} projectStructure - Structure du projet
 * @returns {number} Score de sécurité (0-100)
 */
export function calculateSecurityScore(vulnerabilities, projectStructure) {
  // Score de base
  let score = 100;
  
  // Déductions basées sur les vulnérabilités
  const severityWeights = {
    'critical': 15,
    'high': 10,
    'medium': 5,
    'low': 2
  };
  
  // Compter les vulnérabilités par sévérité
  const countBySeverity = vulnerabilities.reduce((acc, vuln) => {
    acc[vuln.severity] = (acc[vuln.severity] || 0) + 1;
    return acc;
  }, {});
  
  // Appliquer les déductions
  for (const [severity, count] of Object.entries(countBySeverity)) {
    const weight = severityWeights[severity] || 0;
    const deduction = weight * count;
    score -= deduction;
  }
  
  // Bonus pour bonnes pratiques (à implémenter avec une vraie analyse)
  const bonusFeatures = {
    hasTests: 5,
    hasCICD: 5,
    hasDependencyScan: 3,
    hasSecureConfig: 5,
    hasInputValidation: 4
  };
  
  // Simuler la détection de bonnes pratiques
  for (const [feature, bonus] of Object.entries(bonusFeatures)) {
    if (projectStructure[feature]) {
      score += bonus;
    }
  }
  
  // Clamping du score entre 0 et 100
  return Math.max(0, Math.min(100, Math.round(score)));
}