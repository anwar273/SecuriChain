// services/modelSelector.js
/**
 * Sélectionne les modèles LLM optimaux pour l'analyse de sécurité
 * @param {Object} projectStructure - Structure du projet
 * @returns {Array} Liste des modèles sélectionnés
 */
export async function selectOptimalModels(projectStructure) {
  // Liste des modèles disponibles
  const availableModels = [
    {
      name: 'CodeSecurityAnalyst',
      version: '1.0',
      strengths: ['general_code_review', 'pattern_recognition'],
      languages: ['JavaScript', 'Python', 'Java', 'C#', 'PHP', 'Ruby', 'Go'],
      vulnerabilityTypes: ['all'],
      size: 'medium',
      speedRating: 3
    },
    {
      name: 'WebSecurityExpert',
      version: '2.1',
      strengths: ['web_security', 'injection_detection', 'authentication_issues'],
      languages: ['JavaScript', 'PHP', 'Python', 'Ruby'],
      vulnerabilityTypes: ['XSS', 'CSRF', 'SQL_Injection', 'Authentication'],
      size: 'medium',
      speedRating: 4
    },
    {
      name: 'CryptoAnalyzer',
      version: '1.5',
      strengths: ['cryptography_audit', 'key_management', 'encryption_validation'],
      languages: ['all'],
      vulnerabilityTypes: ['Weak_Crypto', 'Key_Management', 'Random_Number_Generation'],
      size: 'small',
      speedRating: 5
    },
    {
      name: 'DataFlowTracker',
      version: '3.0',
      strengths: ['data_flow_analysis', 'input_validation', 'output_encoding'],
      languages: ['all'],
      vulnerabilityTypes: ['Data_Leakage', 'Input_Validation', 'Output_Encoding'],
      size: 'large',
      speedRating: 2
    },
    {
      name: 'DeepCodeAnalyzer',
      version: '2.0',
      strengths: ['deep_code_analysis', 'complex_logic_bugs', 'architectural_flaws'],
      languages: ['JavaScript', 'Python', 'Java', 'C++', 'C#'],
      vulnerabilityTypes: ['Logic_Errors', 'Race_Conditions', 'Memory_Management'],
      size: 'large',
      speedRating: 1
    },
    {
      name: 'APISecurityGuard',
      version: '1.2',
      strengths: ['api_security', 'authentication', 'authorization'],
      languages: ['all'],
      vulnerabilityTypes: ['Authentication', 'Authorization', 'API_Abuse'],
      size: 'medium',
      speedRating: 3
    }
  ];

  // Détermine les caractéristiques du projet qui vont guider la sélection
  const { primaryLanguage, complexity, frameworks } = projectStructure;
  
  // Sélection des modèles basée sur le langage de programmation principal
  let selectedModels = availableModels.filter(model => 
    model.languages.includes(primaryLanguage) || model.languages.includes('all')
  );
  
  // Si le projet est complexe, privilégier les modèles d'analyse profonde
  if (complexity === 'high') {
    selectedModels = selectedModels.filter(model => 
      model.strengths.some(strength => 
        ['deep_code_analysis', 'complex_logic_bugs', 'architectural_flaws'].includes(strength)
      )
    );
  }
  
  // Sélection finale: au moins un modèle généraliste et un ou plusieurs spécialistes
  const generalModels = selectedModels.filter(model => 
    model.strengths.includes('general_code_review')
  ).slice(0, 1);
  
  const specialistModels = selectedModels
    .filter(model => !model.strengths.includes('general_code_review'))
    .sort((a, b) => b.speedRating - a.speedRating)
    .slice(0, 3);
  
  // Configuration du but pour chaque modèle sélectionné
  const configuredModels = [
    ...generalModels.map(model => ({
      ...model,
      purpose: 'Analyse générale de la sécurité du code'
    })),
    ...specialistModels.map(model => {
      // Déterminer le but spécifique en fonction des forces du modèle
      const purpose = model.strengths[0]
        .replace(/_/g, ' ')
        .replace(/\b\w/g, l => l.toUpperCase());
      
      return {
        ...model,
        purpose: `Spécialiste en ${purpose}`
      };
    })
  ];
  
  return configuredModels;
}