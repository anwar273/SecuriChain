// routes/repositories.js
import express from 'express';
import { Octokit } from '@octokit/rest';
import User from '../models/User.js';
import Repository from '../models/Repository.js';

const router = express.Router();

// Récupérer tous les dépôts de l'utilisateur GitHub
router.get('/', async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user || !user.githubToken) {
      return res.status(400).json({ message: 'Token GitHub non configuré' });
    }
    
    // Initialiser l'API GitHub
    const octokit = new Octokit({ auth: user.githubToken });
    
    // Récupérer les dépôts depuis GitHub
    const { data: repos } = await octokit.repos.listForAuthenticatedUser({
      sort: 'updated',
      per_page: 100
    });
    
    // Formater les données
    const repositories = repos.map(repo => ({
      repoId: repo.id.toString(),
      name: repo.name,
      owner: repo.owner.login,
      description: repo.description,
      url: repo.html_url,
      primaryLanguage: repo.language,
      stars: repo.stargazers_count,
      forks: repo.forks_count,
      updatedAt: repo.updated_at
    }));
    
    res.json({ repositories });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des dépôts', error: error.message });
  }
});

// Ajouter un dépôt à la base de données pour suivi
router.post('/track', async (req, res) => {
  try {
    const { repoId, name, owner, description, url, primaryLanguage } = req.body;
    
    // Vérifier si le dépôt est déjà suivi
    const existingRepo = await Repository.findOne({ 
      userId: req.user.userId,
      repoId
    });
    
    if (existingRepo) {
      return res.json({ 
        message: 'Ce dépôt est déjà suivi',
        repository: existingRepo
      });
    }
    
    // Créer un nouveau dépôt suivi
    const repository = new Repository({
      userId: req.user.userId,
      repoId,
      name,
      owner,
      description,
      url,
      primaryLanguage
    });
    
    await repository.save();
    
    // routes/repositories.js (suite)
    res.status(201).json({ 
      message: 'Dépôt ajouté au suivi avec succès',
      repository
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de l\'ajout du dépôt', error: error.message });
  }
});

// Récupérer les dépôts suivis par l'utilisateur
router.get('/tracked', async (req, res) => {
  try {
    const repositories = await Repository.find({ userId: req.user.userId })
      .sort({ createdAt: -1 });
    
    res.json({ repositories });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des dépôts suivis', error: error.message });
  }
});

// Récupérer un dépôt spécifique par son ID
router.get('/tracked/:id', async (req, res) => {
  try {
    const repository = await Repository.findOne({
      _id: req.params.id,
      userId: req.user.userId
    });
    
    if (!repository) {
      return res.status(404).json({ message: 'Dépôt non trouvé' });
    }
    
    res.json({ repository });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération du dépôt', error: error.message });
  }
});

export default router;