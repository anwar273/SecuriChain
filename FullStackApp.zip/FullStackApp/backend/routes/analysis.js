// routes/analysis.js
import express from 'express';
import { Octokit } from '@octokit/rest';
import User from '../models/User.js';
import Repository from '../models/Repository.js';
import SecurityAnalysis from '../models/SecurityAnalysis.js';
import VulnerabilityDatabase from '../models/VulnerabilityDatabase.js';
import { startAnalysisPipeline } from '../services/analysisPipeline.js';

const router = express.Router();

// Démarrer une nouvelle analyse de sécurité
router.post('/start', async (req, res) => {
  try {
    const { repositoryId } = req.body;
    
    // Trouver le dépôt
    const repository = await Repository.findOne({ 
      _id: repositoryId,
      userId: req.user.userId
    });
    
    if (!repository) {
      return res.status(404).json({ message: 'Dépôt non trouvé' });
    }
    
    // Créer une nouvelle analyse
    const analysis = new SecurityAnalysis({
      repositoryId: repository._id,
      userId: req.user.userId,
      status: 'pending'
    });
    
    await analysis.save();
    
    // Démarrer le pipeline d'analyse en arrière-plan
    startAnalysisPipeline(analysis._id, req.user.userId, repository)
      .catch(err => console.error('Error in analysis pipeline:', err));
    
    res.status(201).json({ 
      message: 'Analyse de sécurité démarrée',
      analysisId: analysis._id,
      status: analysis.status
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors du démarrage de l\'analyse', error: error.message });
  }
});

// Obtenir le statut d'une analyse
router.get('/:analysisId', async (req, res) => {
  try {
    const analysis = await SecurityAnalysis.findOne({
      _id: req.params.analysisId,
      userId: req.user.userId
    });
    
    if (!analysis) {
      return res.status(404).json({ message: 'Analyse non trouvée' });
    }
    
    res.json({ analysis });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération de l\'analyse', error: error.message });
  }
});

// Obtenir toutes les analyses d'un dépôt
router.get('/repository/:repoId', async (req, res) => {
  try {
    const repository = await Repository.findOne({
      _id: req.params.repoId,
      userId: req.user.userId
    });
    
    if (!repository) {
      return res.status(404).json({ message: 'Dépôt non trouvé' });
    }
    
    const analyses = await SecurityAnalysis.find({
      repositoryId: repository._id
    }).sort({ startedAt: -1 });
    
    res.json({ analyses });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des analyses', error: error.message });
  }
});

// Obtenir les dernières analyses de tous les dépôts
router.get('/', async (req, res) => {
  try {
    // Trouver tous les dépôts de l'utilisateur
    const repositories = await Repository.find({ userId: req.user.userId });
    const repoIds = repositories.map(repo => repo._id);
    
    // Trouver la dernière analyse pour chaque dépôt
    const analyses = await Promise.all(
      repoIds.map(async (repoId) => {
        return SecurityAnalysis.findOne({ repositoryId: repoId })
          .sort({ startedAt: -1 })
          .limit(1);
      })
    );
    
    // Filtrer les nulls et combiner avec les infos du dépôt
    const results = analyses
      .filter(analysis => analysis !== null)
      .map(analysis => {
        const repo = repositories.find(r => r._id.equals(analysis.repositoryId));
        return {
          analysisId: analysis._id,
          repositoryName: repo.name,
          repositoryOwner: repo.owner,
          startedAt: analysis.startedAt,
          status: analysis.status,
          securityScore: analysis.securityScore,
          vulnerabilitiesCount: analysis.vulnerabilities?.length || 0
        };
      });
    
    res.json({ analyses: results });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des analyses', error: error.message });
  }
});

export default router;