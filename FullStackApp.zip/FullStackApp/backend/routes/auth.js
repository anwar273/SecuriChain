// routes/auth.js
import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Inscription
router.post('/register', async (req, res) => {
  try {
    console.log("Requête d'inscription reçue:", req.body);
    const { email, password } = req.body;
    
    // Vérifier si l'utilisateur existe déjà
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Cet email est déjà utilisé' });
    }
    
    // Créer un nouvel utilisateur
    const user = new User({ email, password });
    await user.save();
    
    // Générer un token JWT
    const token = jwt.sign(
      { userId: user._id }, 
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    console.log(`Utilisateur créé: ${email}, ID: ${user._id}`);
    
    res.status(201).json({ 
      message: 'Utilisateur créé avec succès',
      token,
      user: { id: user._id, email: user.email }
    });
  } catch (error) {
    console.error("Erreur d'inscription:", error);
    res.status(500).json({ message: 'Erreur lors de l\'inscription', error: error.message });
  }
});

// Connexion
router.post('/login', async (req, res) => {
  try {
    console.log("Requête de connexion reçue:", req.body);
    const { email, password } = req.body;
    
    // Validation des données
    if (!email || !password) {
      return res.status(400).json({ message: 'Email et mot de passe requis' });
    }
    
    // Trouver l'utilisateur
    const user = await User.findOne({ email });
    if (!user) {
      console.log(`Tentative de connexion avec email non trouvé: ${email}`);
      return res.status(400).json({ message: 'Email ou mot de passe incorrect' });
    }
    
    // Vérifier le mot de passe
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      console.log(`Tentative de connexion avec mot de passe incorrect pour: ${email}`);
      return res.status(400).json({ message: 'Email ou mot de passe incorrect' });
    }
    
    // Mettre à jour la date de dernière connexion
    user.lastLogin = Date.now();
    await user.save();
    
    // Générer un token JWT
    const token = jwt.sign(
      { userId: user._id }, 
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    console.log(`Connexion réussie pour: ${email}, ID: ${user._id}`);
    
    res.json({ 
      message: 'Connexion réussie',
      token,
      user: { id: user._id, email: user.email, hasGithubToken: !!user.githubToken }
    });
  } catch (error) {
    console.error("Erreur de connexion:", error);
    res.status(500).json({ message: 'Erreur lors de la connexion', error: error.message });
  }
});

/// routes/auth.js - Route github-token corrigée
// Dans routes/auth.js
router.post('/github-token', authenticateToken, async (req, res) => {
  console.log("=== DÉBUT TRAITEMENT GITHUB TOKEN ===");
  console.log("Headers reçus:", req.headers);
  console.log("Corps de la requête:", req.body);
  console.log("User extrait du token:", req.user);
  
  try {
    const userId = req.user.userId;
    const { githubToken } = req.body;
    
    console.log("1. UserId extrait:", userId);
    console.log("2. Token GitHub reçu:", githubToken ? "Présent" : "Absent");
    
    if (!githubToken) {
      console.log("3. Erreur: Token GitHub manquant");
      return res.status(400).json({ message: 'Token GitHub requis' });
    }
    
    // Vérification explicite de la validité de l'ID utilisateur
    if (!userId || typeof userId !== 'string' || !userId.match(/^[0-9a-fA-F]{24}$/)) {
      console.log("3. Erreur: Format d'ID utilisateur invalide:", userId);
      return res.status(400).json({ message: 'Format d\'ID utilisateur invalide' });
    }
    
    console.log("3. Recherche de l'utilisateur dans la base de données...");
    let user;
    try {
      user = await User.findById(userId);
      console.log("4. Résultat de la recherche:", user ? "Utilisateur trouvé" : "Utilisateur non trouvé");
    } catch (dbError) {
      console.error("4. Erreur de recherche MongoDB:", dbError);
      return res.status(500).json({ message: 'Erreur de base de données', error: dbError.message });
    }
    
    if (!user) {
      console.log("5. Utilisateur non trouvé avec l'ID:", userId);
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }
    
    // Mise à jour du token
    console.log("5. Mise à jour du token pour l'utilisateur:", user.email);
    user.githubToken = githubToken;
    
    try {
      await user.save();
      console.log("6. Token GitHub sauvegardé avec succès");
    } catch (saveError) {
      console.error("6. Erreur lors de la sauvegarde:", saveError);
      return res.status(500).json({ message: 'Erreur lors de la sauvegarde', error: saveError.message });
    }
    
    console.log("7. Réponse de succès envoyée");
    res.json({
      message: 'Token GitHub ajouté avec succès',
      user: { id: user._id, email: user.email, hasGithubToken: true }
    });
    
    console.log("=== FIN TRAITEMENT GITHUB TOKEN ===");
  } catch (error) {
    console.error("Erreur globale:", error);
    res.status(500).json({ message: 'Erreur serveur', error: error.message });
  }
});

// Vérifier l'authentification (NOUVELLE ROUTE)
router.get('/verify', authenticateToken, async (req, res) => {
  try {
    console.log("Vérification d'authentification pour userId:", req.user.userId);
    
    // Récupérer les données de l'utilisateur
    const user = await User.findById(req.user.userId);
    
    if (!user) {
      console.log("Utilisateur non trouvé lors de la vérification");
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }
    
    console.log(`Vérification réussie pour: ${user.email}`);
    
    // Renvoyer les informations de l'utilisateur
    res.json({ 
      user: { 
        id: user._id, 
        email: user.email, 
        hasGithubToken: !!user.githubToken 
      }
    });
  } catch (error) {
    console.error("Erreur lors de la vérification:", error);
    res.status(500).json({ message: 'Erreur lors de la vérification', error: error.message });
  }
});

export default router;