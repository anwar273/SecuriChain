// server.js - Point d'entrée principal du backend
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { Octokit } from '@octokit/rest';
import { fileURLToPath } from 'url';
import path from 'path';

// Pour obtenir __dirname en ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Routes
import authRoutes from './routes/auth.js';
import repoRoutes from './routes/repositories.js';
import analysisRoutes from './routes/analysis.js';

// Middleware
import { authenticateToken } from './middleware/auth.js';

// Configuration
dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;
const corsOptions = {
  origin: process.env.NODE_ENV === 'production' ? 'https://votre-domaine.com' : 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  exposedHeaders: ['Content-Length', 'X-Confirm-Delete']
};


// Middleware
app.use(cors(corsOptions));
app.use(express.json());
app.use(morgan('dev'));

// Connexion à MongoDB
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/repositories', authenticateToken, repoRoutes);
app.use('/api/analysis', authenticateToken, analysisRoutes);

// Route de test
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'API is running' });
});

// En production, servir le frontend
if (process.env.NODE_ENV === 'production') {
  // Servir les fichiers statiques du build React
  const frontendPath = path.join(__dirname, '../frontend/build');
  app.use(express.static(frontendPath));
  
  // Pour toute autre route, renvoyer index.html
  app.get('*', (req, res) => {
    res.sendFile(path.join(frontendPath, 'index.html'));
  });
}

// Démarrage du serveur
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});