// models/Repository.js
import mongoose from 'mongoose';

const repositorySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  repoId: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  owner: {
    type: String,
    required: true
  },
  description: String,
  url: String,
  primaryLanguage: String,
  lastAnalysisDate: Date,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Repository = mongoose.model('Repository', repositorySchema);
export default Repository;