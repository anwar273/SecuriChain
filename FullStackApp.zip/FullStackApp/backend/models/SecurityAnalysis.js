// models/SecurityAnalysis.js
import mongoose from 'mongoose';

const vulnerabilitySchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    required: true
  },
  filePath: String,
  lineNumbers: [Number],
  cveReferences: [String],
  recommendation: String,
  codeSnippet: String,
  vulnerabilityType: String,
  detectedBy: {
    type: String,
    required: true
  }
});

const securityAnalysisSchema = new mongoose.Schema({
  repositoryId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Repository',
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  startedAt: {
    type: Date,
    default: Date.now
  },
  completedAt: Date,
  status: {
    type: String,
    enum: ['pending', 'in-progress', 'completed', 'failed'],
    default: 'pending'
  },
  vulnerabilities: [vulnerabilitySchema],
  securityScore: {
    type: Number,
    min: 0,
    max: 100
  },
  usedModels: [{
    name: String,
    version: String,
    purpose: String
  }],
  summary: String,
  errorDetails: String,
  executionTimeSeconds: Number
});

const SecurityAnalysis = mongoose.model('SecurityAnalysis', securityAnalysisSchema);
export default SecurityAnalysis;