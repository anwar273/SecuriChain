import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Navbar from './components/layout/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import RepositoryList from './pages/RepositoryList';
import RepositoryDetail from './pages/RepositoryDetail';
import SecurityAnalysis from './pages/SecurityAnalysis';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';
import './App.css';

// Composant de route protégée
// Component PrivateRoute (à inclure dans App.js ou un fichier séparé)
const PrivateRoute = ({ children }) => {
  const { currentUser, loading } = useAuth();
  const location = useLocation();
  
  console.log("PrivateRoute - État d'authentification:", {
    user: currentUser ? "Présent" : "Absent",
    loading,
    token: localStorage.getItem('token') ? "Présent" : "Absent"
  });
  
  // Pendant le chargement, afficher un indicateur
  if (loading) {
    return <div className="loading">Chargement...</div>;
  }
  
  // Si l'utilisateur n'est pas authentifié, rediriger vers la page de connexion
  if (!currentUser) {
    console.log("PrivateRoute - Redirection vers login");
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  // Si l'utilisateur est authentifié, afficher le contenu protégé
  return children;
};

function App() {
  return (
    <AuthProvider>
      <div className="app">
        <Navbar />
        <main className="container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            } />
            <Route path="/repositories" element={
              <PrivateRoute>
                <RepositoryList />
              </PrivateRoute>
            } />
            <Route path="/repositories/:id" element={
              <PrivateRoute>
                <RepositoryDetail />
              </PrivateRoute>
            } />
            <Route path="/analysis/:id" element={
              <PrivateRoute>
                <SecurityAnalysis />
              </PrivateRoute>
            } />
            <Route path="/settings" element={
              <PrivateRoute>
                <Settings />
              </PrivateRoute>
            } />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </AuthProvider>
  );
}

export default App;