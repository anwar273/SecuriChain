// src/pages/SecurityAnalysis.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Alert from '../components/layout/Alert';
import Loader from '../components/layout/Loader';
import SecurityScoreCard from '../components/dashboard/SecurityScoreCard';
import VulnerabilitySummary from '../components/dashboard/VulnerabilitySummary';
import VulnerabilityDistribution from '../components/dashboard/VulnerabilityDistribution';
import VulnerabilityTable from '../components/dashboard/VulnerabilityTable';
import './SecurityAnalysis.css';

const SecurityAnalysis = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedVulnerability, setSelectedVulnerability] = useState(null);
  const [showModal, setShowModal] = useState(false);
  
  const { id } = useParams();
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchAnalysis = async () => {
      try {
        setLoading(true);
        setError('');
        
        // Essayez d'abord de récupérer depuis l'API backend
        try {
          const token = localStorage.getItem('token');
          
          // Appel API backend
          const response = await fetch(`/api/analysis/${id}`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          
          if (response.ok) {
            const data = await response.json();
            console.log("Données d'analyse récupérées du backend:", data);
            setAnalysis(data.analysis);
            setLoading(false);
            return;
          } else {
            // Si l'API backend échoue, utiliser la simulation
            console.warn("Impossible de récupérer l'analyse depuis l'API");
            throw new Error("API indisponible");
          }
        } catch (backendError) {
          console.warn("Erreur backend:", backendError);
          
          // Mode simulation - Récupérer du localStorage
          console.log("Utilisation du mode simulation");
          const storedResults = localStorage.getItem('currentAnalysisResults');
          
          if (!storedResults) {
            // Si aucun résultat n'est trouvé, rediriger vers la page de simulation
            console.warn("Aucun résultat d'analyse trouvé, redirection vers la simulation");
            navigate('/analysis/simulation');
            return;
          }
          
          // Utiliser les résultats simulés
          setAnalysis(JSON.parse(storedResults));
        }
      } catch (err) {
        console.error("Erreur lors du chargement de l'analyse:", err);
        setError("Erreur lors du chargement de l'analyse");
      } finally {
        setLoading(false);
      }
    };
    
    fetchAnalysis();
  }, [id, navigate]);
  
  const handleViewVulnerabilityDetails = (vulnerability) => {
    setSelectedVulnerability(vulnerability);
    setShowModal(true);
  };
  
  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedVulnerability(null);
  };
  
  if (loading) {
    return <Loader message="Chargement des résultats d'analyse..." />;
  }
  
  if (error) {
    return (
      <div className="security-analysis-page">
        <Alert type="danger" message={error} />
        <div className="text-center mt-4">
          <Link to="/repositories" className="btn btn-primary">
            Retour aux dépôts
          </Link>
        </div>
      </div>
    );
  }
  
  if (!analysis) {
    return (
      <div className="security-analysis-page">
        <Alert type="danger" message="Analyse non trouvée. Veuillez sélectionner un dépôt à analyser." />
        <div className="text-center mt-4">
          <Link to="/repositories" className="btn btn-primary">
            Sélectionner un dépôt
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="security-analysis-page">
      <div className="analysis-header">
        <div className="analysis-info">
          <h1>Rapport d'analyse de sécurité</h1>
          <div className="repo-info">
            <span className="repo-name">{analysis.repositoryName}</span>
            <span className="analysis-date">
              Analyse du {new Date(analysis.completedAt).toLocaleString()}
            </span>
          </div>
        </div>
        
        <div className="analysis-actions">
          <button className="btn btn-secondary">
            Télécharger le rapport PDF
          </button>
          <Link to="/repositories" className="btn btn-primary">
            Retour aux dépôts
          </Link>
        </div>
      </div>
      
      <div className="analysis-tabs">
        <button 
          className={`tab-button ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          Vue d'ensemble
        </button>
        <button 
          className={`tab-button ${activeTab === 'vulnerabilities' ? 'active' : ''}`}
          onClick={() => setActiveTab('vulnerabilities')}
        >
          Vulnérabilités ({analysis.vulnerabilities?.length || 0})
        </button>
        <button 
          className={`tab-button ${activeTab === 'recommendations' ? 'active' : ''}`}
          onClick={() => setActiveTab('recommendations')}
        >
          Recommandations
        </button>
      </div>
      
      <div className="tab-content">
        {/* Vue d'ensemble */}
        {activeTab === 'overview' && (
          <div className="overview-panel">
            <div className="overview-grid">
              <div className="overview-card">
                <SecurityScoreCard 
                  securityScore={analysis.securityScore} 
                  repoName={analysis.repositoryName}
                />
              </div>
              
              <div className="overview-card">
                <VulnerabilitySummary vulnerabilities={analysis.vulnerabilities} />
              </div>
              
              <div className="overview-card">
                <VulnerabilityDistribution vulnerabilities={analysis.vulnerabilities} />
              </div>
              
              <div className="overview-card full-width">
                <div className="summary-card">
                  <h3>Résumé de l'analyse</h3>
                  <p className="summary-text">{analysis.summary}</p>
                  
                  <div className="analysis-details">
                    <div className="detail-item">
                      <span className="detail-label">Durée de l'analyse:</span>
                      <span className="detail-value">
                        {analysis.executionTimeSeconds ? 
                          `${analysis.executionTimeSeconds} secondes` : 
                          'Information non disponible'}
                      </span>
                    </div>
                    
                    <div className="detail-item">
                      <span className="detail-label">Modèles utilisés:</span>
                      <div className="models-list">
                        {analysis.usedModels?.map((model, index) => (
                          <span key={index} className="model-badge">
                            {model.name} v{model.version}
                          </span>
                        )) || 'Information non disponible'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Liste des vulnérabilités */}
        {activeTab === 'vulnerabilities' && (
          <div className="vulnerabilities-panel">
            <VulnerabilityTable 
              vulnerabilities={analysis.vulnerabilities}
              onViewDetails={handleViewVulnerabilityDetails}
            />
          </div>
        )}
        
        {/* Recommandations */}
        {activeTab === 'recommendations' && (
          <div className="recommendations-panel">
            <div className="recommendations-card">
              <h3>Recommandations de sécurité</h3>
              
              {analysis.vulnerabilities && analysis.vulnerabilities.length > 0 ? (
                <div className="recommendations-list">
                  {/* Grouper les recommandations par type */}
                  {Object.entries(
                    analysis.vulnerabilities.reduce((acc, vuln) => {
                      const type = vuln.vulnerabilityType;
                      if (!acc[type]) {
                        acc[type] = {
                          count: 0,
                          recommendation: vuln.recommendation,
                          severity: vuln.severity
                        };
                      }
                      acc[type].count++;
                      
                      // Prendre la recommandation la plus sévère
                      const severityOrder = { 'critical': 3, 'high': 2, 'medium': 1, 'low': 0 };
                      if (severityOrder[vuln.severity] > severityOrder[acc[type].severity]) {
                        acc[type].recommendation = vuln.recommendation;
                        acc[type].severity = vuln.severity;
                      }
                      
                      return acc;
                    }, {})
                  ).sort((a, b) => {
                    // Trier par sévérité
                    const severityOrder = { 'critical': 3, 'high': 2, 'medium': 1, 'low': 0 };
                    return severityOrder[b[1].severity] - severityOrder[a[1].severity];
                  }).map(([type, info], index) => (
                    <div key={index} className={`recommendation-item severity-${info.severity}`}>
                      <div className="recommendation-header">
                        <h4>{type.replace(/_/g, ' ')}</h4>
                        <span className={`severity-badge ${info.severity}`}>
                          {info.severity}
                        </span>
                      </div>
                      <p className="recommendation-text">{info.recommendation}</p>
                      <p className="recommendation-count">
                        Occurrences: <strong>{info.count}</strong>
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="no-data">Aucune vulnérabilité détectée. Excellent travail !</p>
              )}
              
              <div className="general-recommendations">
                <h4>Bonnes pratiques générales</h4>
                <ul>
                  <li>Maintenez vos dépendances à jour pour éviter les vulnérabilités connues</li>
                  <li>Mettez en place des tests de sécurité automatisés dans votre pipeline CI/CD</li>
                  <li>Utilisez des outils d'analyse statique de code dans votre processus de développement</li>
                  <li>Établissez une politique de revue de code avec focus sur la sécurité</li>
                  <li>Formez régulièrement votre équipe aux dernières pratiques de sécurité</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Modal pour les détails de vulnérabilité */}
      {showModal && selectedVulnerability && (
        <div className="vulnerability-modal" onClick={(e) => {
          if (e.target.className === 'vulnerability-modal') {
            handleCloseModal();
          }
        }}>
          <div className="modal-content">
            <div className="modal-header">
              <h3>{selectedVulnerability.title}</h3>
              <button className="modal-close" onClick={handleCloseModal}>&times;</button>
            </div>
            
            <div className="modal-body">
              <div className="vulnerability-meta">
                <div className="meta-item">
                  <span className="meta-label">Sévérité:</span>
                  <span className={`severity-badge ${selectedVulnerability.severity}`}>
                    {selectedVulnerability.severity}
                  </span>
                </div>
                
                <div className="meta-item">
                  <span className="meta-label">Type:</span>
                  <span className="meta-value">
                    {selectedVulnerability.vulnerabilityType}
                  </span>
                </div>
                
                <div className="meta-item">
                  <span className="meta-label">Détecté par:</span>
                  <span className="meta-value">
                    {selectedVulnerability.detectedBy || 'Analyse automatique'}
                  </span>
                </div>
                
                {selectedVulnerability.cveReferences && selectedVulnerability.cveReferences.length > 0 && (
                  <div className="meta-item">
                    <span className="meta-label">Références CVE:</span>
                    <div className="cve-list">
                      {selectedVulnerability.cveReferences.map((cve, index) => (
                        <a 
                          key={index}
                          href={`https://cve.mitre.org/cgi-bin/cvename.cgi?name=${cve}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="cve-link"
                        >
                          {cve}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="vulnerability-section">
                <h4>Description</h4>
                <p>{selectedVulnerability.description}</p>
              </div>
              
              <div className="vulnerability-section">
                <h4>Emplacement</h4>
                <p className="file-path">{selectedVulnerability.filePath}</p>
                {selectedVulnerability.lineNumbers && selectedVulnerability.lineNumbers.length > 0 && (
                  <p className="line-numbers">
                    Lignes: {selectedVulnerability.lineNumbers.join(', ')}
                  </p>
                )}
              </div>
              
              {selectedVulnerability.codeSnippet && (
                <div className="vulnerability-section">
                  <h4>Extrait de code</h4>
                  <pre className="code-snippet">
                    <code>{selectedVulnerability.codeSnippet}</code>
                  </pre>
                </div>
              )}
              
              <div className="vulnerability-section">
                <h4>Recommandation</h4>
                <p>{selectedVulnerability.recommendation}</p>
              </div>
            </div>
            
            <div className="modal-footer">
              <button className="btn btn-primary" onClick={handleCloseModal}>Fermer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecurityAnalysis;