// src/pages/RepositoryList.js
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Alert from '../components/layout/Alert';
import Loader from '../components/layout/Loader';
import './RepositoryList.css';

const RepositoryList = () => {
  const [loading, setLoading] = useState(true);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [error, setError] = useState('');
  const [repositories, setRepositories] = useState([]);
  const [filter, setFilter] = useState('');
  
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRepositories = async () => {
      try {
        setLoading(true);
        setError('');
        
        // Récupérer le token GitHub du localStorage
        const githubToken = localStorage.getItem('githubToken');
        
        if (!githubToken) {
          setError('Veuillez d\'abord configurer votre token GitHub dans les paramètres');
          setLoading(false);
          return;
        }
        
        console.log("Récupération des dépôts GitHub...");
        
        // Utiliser l'API GitHub directement
        const response = await fetch('https://api.github.com/user/repos?sort=updated&per_page=100', {
          headers: {
            'Authorization': `token ${githubToken}`,
            'Accept': 'application/vnd.github.v3+json'
          }
        });
        
        if (!response.ok) {
          throw new Error(`Erreur GitHub: ${response.status} ${response.statusText}`);
        }
        
        const repos = await response.json();
        console.log(`✅ ${repos.length} dépôts récupérés`);
        
        // Formater les données
        const formattedRepos = repos.map(repo => ({
          id: repo.id.toString(),
          name: repo.name,
          owner: repo.owner.login,
          description: repo.description,
          url: repo.html_url,
          primaryLanguage: repo.language,
          stars: repo.stargazers_count,
          forks: repo.forks_count,
          updatedAt: repo.updated_at
        }));
        
        setRepositories(formattedRepos);
      } catch (err) {
        console.error("Erreur lors de la récupération des dépôts:", err);
        setError(`Erreur: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };
    
    fetchRepositories();
  }, []);
  
  // Filtrer les dépôts
  const filteredRepositories = repositories.filter(repo => 
    repo.name.toLowerCase().includes(filter.toLowerCase()) ||
    repo.description?.toLowerCase().includes(filter.toLowerCase())
  );
  
  // Démarrer l'analyse d'un dépôt
  const handleStartAnalysis = async (repo) => {
    try {
      setLoadingAnalysis(true);
      setError('');
      
      console.log(`Démarrage de l'analyse pour: ${repo.name}`);
      
      // 1. Stocker les informations du dépôt dans localStorage pour la simulation
      const analysisRepo = {
        id: repo.id,
        name: repo.name,
        owner: repo.owner,
        language: repo.primaryLanguage,
        url: repo.url
      };
      
      localStorage.setItem('currentAnalysisRepo', JSON.stringify(analysisRepo));
      
      // 2. Créer une nouvelle analyse dans le backend
      try {
        const token = localStorage.getItem('token');
        
        // Essayer d'appeler l'API backend
        const response = await fetch('/api/analysis/start', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ repositoryId: repo.id })
        });
        
        if (response.ok) {
          // Si l'API backend fonctionne
          const data = await response.json();
          console.log("Analyse créée sur le backend:", data);
          
          // Stocker l'ID de l'analyse
          localStorage.setItem('currentAnalysisId', data.analysisId);
          
          // Rediriger vers la page d'analyse
          navigate(`/analysis/${data.analysisId}`);
          return;
        } else {
          // Si l'API backend échoue, continuer avec la simulation
          console.warn("L'API backend a échoué, utilisation du mode simulation");
          throw new Error("Erreur de communication avec le serveur");
        }
      } catch (backendError) {
        console.warn("Erreur backend:", backendError);
        console.log("Utilisation du mode simulation");
        
        // 3. Rediriger vers la page de simulation d'analyse
        navigate('/analysis/simulation');
      }
    } catch (err) {
      console.error("Erreur:", err);
      setError(`Erreur lors du démarrage de l'analyse: ${err.message}`);
      setLoadingAnalysis(false);
    }
  };
  
  if (loading) {
    return <Loader message="Chargement des dépôts GitHub..." />;
  }
  
  return (
    <div className="repository-list-page">
      <div className="repo-header">
        <h1>Vos dépôts GitHub</h1>
        <Link to="/settings" className="btn btn-secondary">
          Configurer GitHub
        </Link>
      </div>
      
      {error && <Alert type="danger" message={error} onClose={() => setError('')} />}
      
      <div className="repo-filter">
        <input
          type="text"
          placeholder="Rechercher un dépôt..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="form-control"
        />
      </div>
      
      {filteredRepositories.length === 0 ? (
        <div className="no-repos">
          <p>Aucun dépôt trouvé. Assurez-vous que votre token GitHub est valide et que vous avez des dépôts.</p>
        </div>
      ) : (
        <div className="repo-grid">
          {filteredRepositories.map(repo => (
            <div key={repo.id} className="repo-card">
              <div className="repo-card-header">
                <h3 className="repo-name">{repo.name}</h3>
                {repo.primaryLanguage && (
                  <span className="repo-language">{repo.primaryLanguage}</span>
                )}
              </div>
              
              <p className="repo-owner">par {repo.owner}</p>
              
              {repo.description && (
                <p className="repo-description">{repo.description}</p>
              )}
              
              <div className="repo-stats">
                <span className="repo-stat">
                  <span className="stat-icon">⭐</span> {repo.stars || 0}
                </span>
                <span className="repo-stat">
                  <span className="stat-icon">🍴</span> {repo.forks || 0}
                </span>
                <span className="repo-stat">
                  Mis à jour le {new Date(repo.updatedAt).toLocaleDateString()}
                </span>
              </div>
              
              <div className="repo-actions">
                <button 
                  className="btn btn-primary"
                  onClick={() => handleStartAnalysis(repo)}
                  disabled={loadingAnalysis}
                >
                  {loadingAnalysis ? 'Démarrage...' : 'Analyser'}
                </button>
                <a 
                  href={repo.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="btn-link"
                >
                  Voir sur GitHub
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RepositoryList;