// src/pages/RepositoryDetail.js
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import Loader from '../components/layout/Loader';
import Alert from '../components/layout/Alert';
import SecurityScoreCard from '../components/dashboard/SecurityScoreCard';
import VulnerabilitySummary from '../components/dashboard/VulnerabilitySummary';
import VulnerabilityTable from '../components/dashboard/VulnerabilityTable';
import repositoryService from '../services/repositoryService';
import analysisService from '../services/analysisService';
import './RepositoryDetail.css';

const RepositoryDetail = () => {
  const [loading, setLoading] = useState(true);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [error, setError] = useState('');
  const [repository, setRepository] = useState(null);
  const [analyses, setAnalyses] = useState([]);
  const [currentAnalysis, setCurrentAnalysis] = useState(null);
  const [analysisStarted, setAnalysisStarted] = useState(false);
  
  const { id } = useParams();
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Récupérer les informations du dépôt et ses analyses
        const [repoData, analysesData] = await Promise.all([
          repositoryService.getRepositoryById(id),
          analysisService.getRepositoryAnalyses(id)
        ]);
        
        setRepository(repoData);
        setAnalyses(analysesData);
        
        // Si des analyses sont disponibles, sélectionner la plus récente
        if (analysesData.length > 0) {
          // Trier par date, de la plus récente à la plus ancienne
          const latestAnalysis = analysesData.sort((a, b) => 
            new Date(b.startedAt) - new Date(a.startedAt)
          )[0];
          
          setCurrentAnalysis(latestAnalysis);
        }
      } catch (err) {
        setError('Erreur lors de la récupération des données du dépôt');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [id]);
  
  // Démarrer une nouvelle analyse
  const handleStartAnalysis = async () => {
    try {
      setAnalysisLoading(true);
      setAnalysisStarted(false);
      setError('');
      
      const result = await analysisService.startAnalysis(id);
      
      // Mettre à jour la liste des analyses et sélectionner la nouvelle
      const updatedAnalyses = await analysisService.getRepositoryAnalyses(id);
      setAnalyses(updatedAnalyses);
      
      // Trouver l'analyse qui vient d'être démarrée
      const newAnalysis = updatedAnalyses.find(a => a._id === result.analysisId);
      setCurrentAnalysis(newAnalysis);
      setAnalysisStarted(true);
      
      // Vérifier régulièrement le statut de l'analyse
      const intervalId = analysisService.pollAnalysisStatus(
        result.analysisId,
        (updatedAnalysis) => {
          setCurrentAnalysis(updatedAnalysis);
          
          if (updatedAnalysis.status === 'completed') {
            setAnalysisLoading(false);
          }
        }
      );
      
      // Nettoyer l'intervalle lorsque le composant est démonté
      return () => clearInterval(intervalId);
    } catch (err) {
      setError('Erreur lors du démarrage de l\'analyse');
      console.error(err);
      setAnalysisLoading(false);
    }
  };
  
  // Sélectionner une analyse spécifique
  const handleSelectAnalysis = async (analysisId) => {
    try {
      const analysis = analyses.find(a => a._id === analysisId);
      
      if (analysis) {
        setCurrentAnalysis(analysis);
      }
    } catch (err) {
      setError('Erreur lors de la sélection de l\'analyse');
      console.error(err);
    }
  };
  
  // Naviguer vers la page de détail de l'analyse
  const handleViewFullReport = () => {
    if (currentAnalysis) {
      navigate(`/analysis/${currentAnalysis._id}`);
    }
  };
  
  if (loading) {
    return <Loader message="Chargement des informations du dépôt..." />;
  }
  
  if (!repository) {
    return (
      <div className="repository-detail-page">
        <Alert type="danger" message="Dépôt non trouvé" />
        <Link to="/repositories" className="btn btn-primary">
          Retour à la liste des dépôts
        </Link>
      </div>
    );
  }
  
  return (
    <div className="repository-detail-page">
      <div className="repo-detail-header">
        <div className="repo-info">
          <h1>{repository.name}</h1>
          <div className="repo-meta">
            <span className="repo-owner">
              Propriétaire: {repository.owner}
            </span>
            {repository.primaryLanguage && (
              <span className="repo-language">
                Langage: {repository.primaryLanguage}
              </span>
            )}
          </div>
        </div>
        
        <div className="repo-actions">
          <button 
            className="btn btn-primary"
            onClick={handleStartAnalysis}
            disabled={analysisLoading}
          >
            {analysisLoading ? 'Analyse en cours...' : 'Lancer une nouvelle analyse'}
          </button>
          <a 
            href={repository.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn btn-secondary"
          >
            Voir sur GitHub
          </a>
        </div>
      </div>
      
      {error && <Alert type="danger" message={error} />}
      
      {analysisStarted && currentAnalysis && currentAnalysis.status === 'pending' && (
        <Alert 
          type="info" 
          message="Analyse démarrée ! Cette page sera mise à jour automatiquement lorsque les résultats seront disponibles." 
        />
      )}
      
      {analyses.length > 0 && (
        <div className="analysis-selector">
          <label htmlFor="analysis-select">Sélectionner une analyse:</label>
          <select 
            id="analysis-select"
            value={currentAnalysis?._id || ''}
            onChange={(e) => handleSelectAnalysis(e.target.value)}
            className="form-control"
          >
            {analyses.map(analysis => (
              <option key={analysis._id} value={analysis._id}>
                {new Date(analysis.startedAt).toLocaleString()} - 
                {analysis.status === 'completed' 
                  ? ` Score: ${analysis.securityScore}`
                  : ` Statut: ${analysis.status}`}
              </option>
            ))}
          </select>
        </div>
      )}
      
      {analysisLoading && (
        <div className="analysis-loading">
          <Loader message="Analyse en cours... Cela peut prendre quelques minutes." />
          {currentAnalysis && currentAnalysis.status !== 'pending' && (
            <div className="analysis-status">
              <p>Statut actuel: <strong>{currentAnalysis.status}</strong></p>
            </div>
          )}
        </div>
      )}
      
      {!analysisLoading && currentAnalysis && currentAnalysis.status === 'completed' && (
        <div className="analysis-results">
          <div className="results-header">
            <h2>Résultats de l'analyse</h2>
            <button 
              className="btn btn-primary"
              onClick={handleViewFullReport}
            >
              Voir le rapport complet
            </button>
          </div>
          
          <div className="results-grid">
            <div className="result-card">
              <SecurityScoreCard 
                securityScore={currentAnalysis.securityScore} 
                repoId={repository._id}
                repoName={repository.name}
              />
            </div>
            
            <div className="result-card">
              <VulnerabilitySummary vulnerabilities={currentAnalysis.vulnerabilities} />
            </div>
            
            <div className="result-card full-width">
              <VulnerabilityTable vulnerabilities={currentAnalysis.vulnerabilities} />
            </div>
          </div>
        </div>
      )}
      
      {!analysisLoading && (!currentAnalysis || currentAnalysis.status === 'failed') && (
        <div className="no-analysis">
          <p>
            {!currentAnalysis 
              ? 'Aucune analyse n\'a encore été effectuée pour ce dépôt.' 
              : 'La dernière analyse a échoué. Veuillez réessayer ou contacter le support.'}
          </p>
          <button 
            className="btn btn-primary"
            onClick={handleStartAnalysis}
          >
            Lancer une analyse
          </button>
        </div>
      )}
    </div>
  );
};

export default RepositoryDetail;