// pages/Settings.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Octokit } from '@octokit/rest';
import Alert from '../components/layout/Alert';
import Loader from '../components/layout/Loader';
import './Settings.css';

const Settings = () => {
  const [githubToken, setGithubToken] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [validating, setValidating] = useState(false);
  const [githubUser, setGithubUser] = useState(null);
  const [storedToken, setStoredToken] = useState(localStorage.getItem('githubToken'));
  
  const { currentUser, addGithubToken } = useAuth();
  const navigate = useNavigate();

  // Vérifier si un token GitHub est déjà stocké
  useEffect(() => {
    const checkExistingToken = async () => {
      const token = localStorage.getItem('githubToken');
      if (token) {
        setStoredToken(token);
        try {
          setValidating(true);
          const userData = await validateGithubTokenSilent(token);
          if (userData) {
            setGithubUser(userData);
          }
        } catch (error) {
          console.error("Token stocké invalide:", error);
          // Supprimer le token invalide
          localStorage.removeItem('githubToken');
          setStoredToken(null);
        } finally {
          setValidating(false);
        }
      }
    };
    
    checkExistingToken();
  }, []);

  // Valider le token GitHub sans afficher d'erreurs (pour vérification silencieuse)
  const validateGithubTokenSilent = async (token) => {
    try {
      const octokit = new Octokit({ auth: token });
      const { data } = await octokit.users.getAuthenticated();
      return data;
    } catch (error) {
      throw error;
    }
  };

  // Valider le token GitHub avec retour utilisateur
  const validateGithubToken = async (token) => {
    try {
      console.log("Validation du token GitHub...");
      
      const octokit = new Octokit({ auth: token });
      
      // Vérifier l'authentification
      const { data: userData } = await octokit.users.getAuthenticated();
      console.log("✅ Authentification GitHub réussie pour:", userData.login);
      
      // Tester les permissions en récupérant quelques dépôts
      console.log("Vérification des permissions du token...");
      const { data: repos } = await octokit.repos.listForAuthenticatedUser({
        per_page: 1 // Juste pour tester l'accès
      });
      
      console.log(`✅ Accès aux dépôts vérifié! (${repos.length} dépôts accessibles)`);
      
      setGithubUser(userData);
      return userData;
    } catch (error) {
      console.error("❌ Erreur de validation du token GitHub:", error.message);
      
      // Générer un message d'erreur plus explicite
      let errorMessage = "Token GitHub invalide";
      
      if (error.status === 401) {
        errorMessage = "Token GitHub non valide ou expiré";
      } else if (error.message.includes("permission")) {
        errorMessage = "Le token ne dispose pas des permissions nécessaires (repo, read:user)";
      }
      
      setError(errorMessage);
      return null;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!githubToken) {
      return setError('Veuillez entrer un token GitHub');
    }
    
    try {
      setLoading(true);
      setError('');
      setSuccess('');
      
      // Étape 1: Valider le token avec GitHub
      console.log("Validation du token GitHub...");
      const userData = await validateGithubToken(githubToken);
      
      if (!userData) {
        setLoading(false);
        return;
      }
      
      console.log("Token GitHub validé avec succès!");
      
      // Étape 2: Stocker le token
      // A. Dans localStorage pour utilisation directe
      console.log("Stockage du token dans localStorage...");
      localStorage.setItem('githubToken', githubToken);
      setStoredToken(githubToken);
      
      // B. Dans le backend si possible
      try {
        console.log("Tentative de stockage dans la base de données...");
        await addGithubToken(githubToken);
        console.log("Token stocké dans la base de données avec succès!");
      } catch (backendError) {
        console.warn("Note: Échec du stockage dans la base de données, mais le token est stocké localement");
        console.error("Détail de l'erreur backend:", backendError);
        // On continue car le token est déjà dans localStorage
      }
      
      // Afficher la confirmation
      setSuccess(`Token GitHub ajouté avec succès pour ${userData.login}`);
      setGithubToken(''); // Effacer le champ
      
      // Rediriger après un délai
      setTimeout(() => {
        navigate('/repositories');
      }, 2000);
    } catch (err) {
      console.error("Erreur globale:", err);
      setError(err.message || 'Une erreur inattendue est survenue');
    } finally {
      setLoading(false);
    }
  };
  
  // Supprimer le token existant
  const handleRemoveToken = () => {
    try {
      localStorage.removeItem('githubToken');
      setStoredToken(null);
      setGithubUser(null);
      setSuccess('Token GitHub supprimé avec succès');
      
      // Essayer de mettre à jour dans le backend aussi
      try {
        addGithubToken(null); // Envoi d'un token null pour le supprimer
      } catch (error) {
        console.warn("Échec de la suppression du token dans la base de données");
      }
    } catch (error) {
      setError("Erreur lors de la suppression du token");
    }
  };
  
  return (
    <div className="settings-page">
      <div className="settings-header">
        <h1>Paramètres</h1>
      </div>
      
      <div className="settings-content">
        <div className="settings-card">
          <h2>Configuration GitHub</h2>
          
          {error && <Alert type="danger" message={error} onClose={() => setError('')} />}
          {success && <Alert type="success" message={success} onClose={() => setSuccess('')} />}
          
          {/* Statut actuel de la connexion GitHub */}
          {validating ? (
            <div className="github-status">
              <Loader message="Vérification du token GitHub..." />
            </div>
          ) : storedToken ? (
            <div className="github-status connected">
              <div className="status-header">
                <h3>État de la connexion GitHub</h3>
                <button 
                  className="btn btn-danger btn-sm"
                  onClick={handleRemoveToken}
                >
                  Déconnecter
                </button>
              </div>
              
              {githubUser && (
                <div className="github-user-info">
                  <div className="user-profile">
                    <img 
                      src={githubUser.avatar_url} 
                      alt={`${githubUser.login} avatar`} 
                      className="avatar"
                    />
                    <div className="user-details">
                      <p className="username">{githubUser.login}</p>
                      {githubUser.name && <p className="name">{githubUser.name}</p>}
                      <p className="connection-status">
                        <span className="status-dot"></span>
                        Connecté à GitHub
                      </p>
                    </div>
                  </div>
                  <div className="user-actions">
                    <button 
                      className="btn btn-primary"
                      onClick={() => navigate('/repositories')}
                    >
                      Voir mes dépôts
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="settings-section">
              <p>
                Pour analyser vos dépôts GitHub, vous devez fournir un token d'accès personnel GitHub avec les permissions suivantes:
              </p>
              
              <ul className="permissions-list">
                <li>
                  <strong>repo</strong> - Accès complet aux dépôts privés et publics
                </li>
                <li>
                  <strong>read:user</strong> - Lecture des données utilisateur
                </li>
              </ul>
              
              <div className="github-token-instructions">
                <h3>Comment générer un token GitHub</h3>
                <ol>
                  <li>Connectez-vous à <a href="https://github.com" target="_blank" rel="noopener noreferrer">GitHub</a></li>
                  <li>Accédez à <strong>Settings &gt; Developer settings &gt; Personal access tokens &gt; Tokens (classic)</strong></li>
                  <li>Cliquez sur <strong>Generate new token (classic)</strong></li>
                  <li>Donnez un nom à votre token (par exemple: "SecuriChain")</li>
                  <li>Sélectionnez les permissions mentionnées ci-dessus</li>
                  <li>Cliquez sur <strong>Generate token</strong></li>
                  <li>Copiez le token généré et collez-le ci-dessous</li>
                </ol>
              </div>
              
              <form onSubmit={handleSubmit} className="github-token-form">
                <div className="form-group">
                  <label htmlFor="github-token">Token GitHub</label>
                  <input
                    type="text"
                    id="github-token"
                    className="form-control"
                    placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                    value={githubToken}
                    onChange={(e) => setGithubToken(e.target.value)}
                    disabled={loading}
                  />
                  <small className="form-text">
                    Votre token sera stocké de façon sécurisée et utilisé uniquement pour accéder à vos dépôts.
                  </small>
                </div>
                
                <button 
                  type="submit" 
                  className="btn btn-primary btn-block" 
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner"></span>
                      Validation du token...
                    </>
                  ) : 'Connecter à GitHub'}
                </button>
              </form>
            </div>
          )}
        </div>
        
        <div className="settings-card">
          <h2>Informations du compte</h2>
          
          <div className="settings-section">
            <div className="account-info">
              <div className="info-item">
                <span className="info-label">Email:</span>
                <span className="info-value">{currentUser?.email}</span>
              </div>
              
              <div className="info-item">
                <span className="info-label">Status GitHub:</span>
                <span className="info-value">
                  {storedToken ? (
                    <span className="status-connected">Connecté</span>
                  ) : (
                    <span className="status-disconnected">Non connecté</span>
                  )}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;