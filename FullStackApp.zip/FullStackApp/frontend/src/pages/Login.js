// pages/Login.js
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Alert from '../components/layout/Alert';
import './Auth.css';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const { email, password } = formData;
  
  // Rediriger si déjà authentifié
  useEffect(() => {
    if (isAuthenticated) {
      const from = location.state?.from?.pathname || '/dashboard';
      navigate(from);
    }
  }, [isAuthenticated, navigate, location]);
  
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    console.log("Soumission du formulaire de connexion");
    
    if (!email || !password) {
      return setError('Veuillez remplir tous les champs');
    }
    
    try {
      setLoading(true);
      setError('');
      setSuccess('');
      
      console.log("Tentative de connexion...");
      await login(email, password);
      
      setSuccess('Connexion réussie! Redirection...');
      console.log("Connexion réussie, redirection...");
      
      // Ajouter un délai avant la redirection
      setTimeout(() => {
        const from = location.state?.from?.pathname || '/dashboard';
        navigate(from);
      }, 500);
    } catch (err) {
      setLoading(false);
      console.error("Erreur lors de la connexion:", err);
      setError(err.response?.data?.message || 'Erreur lors de la connexion');
    }
  };
  
  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          <h2>Connexion</h2>
          <p className="auth-subtitle">Accédez à votre compte SecuriChain</p>
          
          {error && <Alert type="danger" message={error} />}
          {success && <Alert type="success" message={success} />}
          
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                className="form-control"
                value={email}
                onChange={handleChange}
                disabled={loading}
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="password">Mot de passe</label>
              <input
                type="password"
                id="password"
                name="password"
                className="form-control"
                value={password}
                onChange={handleChange}
                disabled={loading}
                required
              />
            </div>
            
            <button 
              type="submit" 
              className="btn btn-primary btn-block" 
              disabled={loading}
            >
              {loading ? 'Connexion en cours...' : 'Se connecter'}
            </button>
          </form>
          
          <div className="auth-links">
            <p>
              Vous n'avez pas de compte ? <Link to="/register">Inscrivez-vous</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;