// src/pages/Home.js
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './Home.css';

const Home = () => {
  const { isAuthenticated } = useAuth();
  
  return (
    <div className="home-page">
      <section className="hero">
        <div className="hero-content">
          <h1>Sécurisez vos dépôts GitHub avec l'IA</h1>
          <p className="hero-subtitle">
            Une plateforme intelligente qui utilise des modèles de langage avancés pour analyser vos dépôts GitHub et détecter les vulnérabilités de sécurité
          </p>
          {isAuthenticated ? (
            <Link to="/dashboard" className="btn btn-primary hero-btn">
              Accéder à votre Dashboard
            </Link>
          ) : (
            <div className="hero-buttons">
              <Link to="/login" className="btn btn-secondary hero-btn">
                Connexion
              </Link>
              <Link to="/register" className="btn btn-primary hero-btn">
                Commencer gratuitement
              </Link>
            </div>
          )}
        </div>
      </section>
      
      <section className="features">
        <div className="container">
          <h2 className="section-title">Fonctionnalités principales</h2>
          
          <div className="flex-row">
            <div className="col-4">
              <div className="feature-box">
                <div className="feature-icon">🤖</div>
                <h3>Pipeline Agentique Intelligent</h3>
                <p>Notre système sélectionne dynamiquement les meilleurs modèles IA pour analyser votre code en fonction du langage et de la structure du projet.</p>
              </div>
            </div>
            
            <div className="col-4">
              <div className="feature-box">
                <div className="feature-icon">🔍</div>
                <h3>Analyse Complète des Vulnérabilités</h3>
                <p>Notre système se connecte aux bases de données de vulnérabilités comme CVE et NVD pour intégrer les dernières informations de sécurité.</p>
              </div>
            </div>
            
            <div className="col-4">
              <div className="feature-box">
                <div className="feature-icon">📊</div>
                <h3>Dashboard Interactif</h3>
                <p>Visualisez facilement les problèmes de sécurité avec un dashboard intuitif offrant des métriques claires et des recommandations précises.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="how-it-works">
        <div className="container">
          <h2 className="section-title">Comment ça marche ?</h2>
          
          <div className="steps">
            <div className="step">
              <div className="step-number">1</div>
              <h3>Connectez votre compte GitHub</h3>
              <p>Ajoutez un token d'accès personnel GitHub à votre compte pour permettre l'analyse de vos dépôts.</p>
            </div>
            
            <div className="step">
              <div className="step-number">2</div>
              <h3>Sélectionnez un dépôt</h3>
              <p>Choisissez parmi vos dépôts GitHub celui que vous souhaitez analyser en termes de sécurité.</p>
            </div>
            
            <div className="step">
              <div className="step-number">3</div>
              <h3>Lancez l'analyse</h3>
              <p>Notre système IA analyse automatiquement votre code source pour détecter les vulnérabilités.</p>
            </div>
            
            <div className="step">
              <div className="step-number">4</div>
              <h3>Consultez le rapport</h3>
              <p>Recevez un rapport détaillé avec des recommandations concrètes pour améliorer la sécurité.</p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="cta">
        <div className="container">
          <h2>Prêt à sécuriser vos projets ?</h2>
          <p>Commencez dès maintenant à identifier et corriger les vulnérabilités dans votre code</p>
          {isAuthenticated ? (
            <Link to="/repositories" className="btn btn-primary">
              Analyser un dépôt
            </Link>
          ) : (
            <Link to="/register" className="btn btn-primary">
              Créer un compte
            </Link>
          )}
        </div>
      </section>
    </div>
  );
};

export default Home;