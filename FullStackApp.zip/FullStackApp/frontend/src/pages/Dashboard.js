// src/pages/Dashboard.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Loader from '../components/layout/Loader';
import Alert from '../components/layout/Alert';
import SecurityScoreCard from '../components/dashboard/SecurityScoreCard';
import VulnerabilitySummary from '../components/dashboard/VulnerabilitySummary';
import VulnerabilityDistribution from '../components/dashboard/VulnerabilityDistribution';
import RecentAnalyses from '../components/dashboard/RecentAnalyses';
import analysisService from '../services/analysisService';
import './Dashboard.css';

const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [analyses, setAnalyses] = useState([]);
  const [latestAnalysis, setLatestAnalysis] = useState(null);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Récupérer les dernières analyses
        const latestAnalyses = await analysisService.getLatestAnalyses();
        setAnalyses(latestAnalyses);
        
        // Si des analyses sont disponibles, récupérer les détails de la plus récente
        if (latestAnalyses.length > 0) {
          const mostRecent = latestAnalyses.find(a => a.status === 'completed');
          
          if (mostRecent) {
            const analysisDetails = await analysisService.getAnalysis(mostRecent.analysisId);
            setLatestAnalysis(analysisDetails);
          }
        }
      } catch (err) {
        setError('Erreur lors du chargement des données');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  if (loading) {
    return <Loader message="Chargement du dashboard..." />;
  }
  
  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <h1>Dashboard de Sécurité</h1>
        <Link to="/repositories" className="btn btn-primary">
          Analyser un nouveau dépôt
        </Link>
      </div>
      
      {error && <Alert type="danger" message={error} />}
      
      {analyses.length === 0 ? (
        <div className="no-data-container">
          <div className="no-data-message">
            <h2>Aucune analyse disponible</h2>
            <p>
              Vous n'avez pas encore analysé de dépôt GitHub. Commencez par ajouter votre token GitHub dans les paramètres, puis lancez votre première analyse.
            </p>
            <div className="no-data-actions">
              <Link to="/settings" className="btn btn-secondary">
                Configurer GitHub
              </Link>
              <Link to="/repositories" className="btn btn-primary">
                Voir vos dépôts
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <div className="dashboard-content">
          <div className="dashboard-row">
            {latestAnalysis && latestAnalysis.securityScore && (
              <div className="dashboard-col col-4">
                <SecurityScoreCard 
                  securityScore={latestAnalysis.securityScore}
                  repoId={latestAnalysis.repositoryId}
                  repoName={analyses.find(a => a.analysisId === latestAnalysis._id)?.repositoryName}
                />
              </div>
            )}
            
            {latestAnalysis && latestAnalysis.vulnerabilities && (
              <div className="dashboard-col col-8">
                <VulnerabilitySummary 
                  vulnerabilities={latestAnalysis.vulnerabilities}
                  showLink={true}
                  analysisId={latestAnalysis._id}
                />
              </div>
            )}
          </div>
          
          <div className="dashboard-row">
            {latestAnalysis && latestAnalysis.vulnerabilities && latestAnalysis.vulnerabilities.length > 0 && (
              <div className="dashboard-col col-6">
                <VulnerabilityDistribution 
                  vulnerabilities={latestAnalysis.vulnerabilities}
                />
              </div>
            )}
            
            <div className="dashboard-col col-6">
              <RecentAnalyses analyses={analyses} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;