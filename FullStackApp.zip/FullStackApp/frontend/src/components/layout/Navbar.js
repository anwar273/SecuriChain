// src/components/layout/Navbar.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { currentUser, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <nav className="navbar">
      <div className="container navbar-container">
        <Link to="/" className="navbar-logo">
          <span className="logo-icon">🔒</span>
          <span className="logo-text">SecuriChain</span>
        </Link>
        
        <div className="navbar-menu">
          {isAuthenticated ? (
            <>
              <Link to="/dashboard" className="navbar-item">Dashboard</Link>
              <Link to="/repositories" className="navbar-item">Dépôts</Link>
              <Link to="/settings" className="navbar-item">Paramètres</Link>
              <button onClick={handleLogout} className="navbar-item logout-btn">
                Déconnexion
              </button>
              <span className="navbar-user">
                <span className="user-icon">👤</span>
                <span className="user-email">{currentUser.email}</span>
              </span>
            </>
          ) : (
            <>
              <Link to="/login" className="navbar-item">Connexion</Link>
              <Link to="/register" className="navbar-item btn-primary">Inscription</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;