// src/components/dashboard/RecentAnalyses.js
import React from 'react';
import { Link } from 'react-router-dom';
import './DashboardComponents.css';

const RecentAnalyses = ({ analyses }) => {
  // Fonction pour formater la date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };
  
  // Fonction pour obtenir la couleur du score
  const getScoreColor = (score) => {
    if (score >= 90) return '#4caf50';
    if (score >= 70) return '#8bc34a';
    if (score >= 50) return '#ffeb3b';
    if (score >= 30) return '#ff9800';
    return '#f44336';
  };
  
  // Fonction pour afficher le statut
  const getStatusBadge = (status) => {
    const statusMap = {
      'pending': { class: 'status-pending', label: 'En attente' },
      'in-progress': { class: 'status-progress', label: 'En cours' },
      'completed': { class: 'status-completed', label: 'Terminé' },
      'failed': { class: 'status-failed', label: 'Échoué' }
    };
    
    const { class: className, label } = statusMap[status] || { class: '', label: status };
    
    return (
      <span className={`status-badge ${className}`}>
        {label}
      </span>
    );
  };
  
  return (
    <div className="recent-analyses card">
      <h3>Analyses Récentes</h3>
      
      {analyses.length > 0 ? (
        <div className="analyses-list">
          {analyses.map((analysis, index) => (
            <div key={index} className="analysis-item">
              <div className="analysis-header">
                <h4 className="repo-name">{analysis.repositoryName}</h4>
                {getStatusBadge(analysis.status)}
              </div>
              
              <div className="analysis-info">
                <div className="analysis-date">
                  <span className="info-label">Analyse du:</span>
                  <span className="info-value">{formatDate(analysis.startedAt)}</span>
                </div>
                
                {analysis.status === 'completed' && (
                  <div className="analysis-score">
                    <span className="info-label">Score:</span>
                    <span 
                      className="info-value score"
                      style={{ color: getScoreColor(analysis.securityScore) }}
                    >
                      {analysis.securityScore}
                    </span>
                  </div>
                )}
                
                <div className="analysis-vulns">
                  <span className="info-label">Vulnérabilités:</span>
                  <span className="info-value">
                    {analysis.vulnerabilitiesCount || 'N/A'}
                  </span>
                </div>
              </div>
              
              <div className="analysis-actions">
                <Link to={`/analysis/${analysis.analysisId}`} className="btn btn-primary">
                  Voir le rapport
                </Link>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="no-analyses">
          <p>Aucune analyse n'a encore été effectuée.</p>
          <Link to="/repositories" className="btn btn-primary">
            Analyser un dépôt
          </Link>
        </div>
      )}
    </div>
  );
};

export default RecentAnalyses;