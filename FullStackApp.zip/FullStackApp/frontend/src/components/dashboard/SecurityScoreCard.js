// src/components/dashboard/SecurityScoreCard.js
import React from 'react';
import { Link } from 'react-router-dom';
import './DashboardComponents.css';

const SecurityScoreCard = ({ securityScore, repoId, repoName }) => {
  // Détermine la couleur du score basée sur la valeur
  const getScoreColor = (score) => {
    if (score >= 90) return '#4caf50'; // Vert
    if (score >= 70) return '#8bc34a'; // Vert clair
    if (score >= 50) return '#ffeb3b'; // Jaune
    if (score >= 30) return '#ff9800'; // Orange
    return '#f44336'; // Rouge
  };

  // Style pour l'arc de cercle
  const circleRadius = 40;
  const circleCircumference = 2 * Math.PI * circleRadius;
  const scoreOffset = circleCircumference - (securityScore / 100) * circleCircumference;
  const scoreColor = getScoreColor(securityScore);

  return (
    <div className="security-score-card card">
      <div className="score-header">
        <h3>Score de Sécurité</h3>
        {repoId && repoName && (
          <Link to={`/repositories/${repoId}`} className="repo-link">
            {repoName}
          </Link>
        )}
      </div>
      
      <div className="score-circle-container">
        <svg width="120" height="120" viewBox="0 0 120 120">
          {/* Cercle de fond */}
          <circle
            cx="60"
            cy="60"
            r={circleRadius}
            fill="none"
            stroke="#e0e0e0"
            strokeWidth="8"
          />
          
          {/* Arc de score */}
          <circle
            cx="60"
            cy="60"
            r={circleRadius}
            fill="none"
            stroke={scoreColor}
            strokeWidth="8"
            strokeDasharray={circleCircumference}
            strokeDashoffset={scoreOffset}
            strokeLinecap="round"
            transform="rotate(-90 60 60)"
          />
          
          {/* Score au centre */}
          <text
            x="60"
            y="60"
            dominantBaseline="middle"
            textAnchor="middle"
            fontSize="24"
            fontWeight="bold"
            fill={scoreColor}
          >
            {securityScore}
          </text>
          
          {/* Label sous le score */}
          <text
            x="60"
            y="78"
            dominantBaseline="middle"
            textAnchor="middle"
            fontSize="12"
            fill="#757575"
          >
            sur 100
          </text>
        </svg>
      </div>
      
      {/* Description du score */}
      <div className="score-description">
        {securityScore >= 90 ? (
          <p>Excellente sécurité ! Continuez ainsi.</p>
        ) : securityScore >= 70 ? (
          <p>Bonne sécurité. Quelques points à améliorer.</p>
        ) : securityScore >= 50 ? (
          <p>Sécurité moyenne. Plusieurs vulnérabilités à corriger.</p>
        ) : securityScore >= 30 ? (
          <p>Sécurité faible. Attention, des vulnérabilités critiques sont présentes.</p>
        ) : (
          <p>Sécurité critique. Action immédiate requise !</p>
        )}
      </div>
    </div>
  );
};

export default SecurityScoreCard;