// src/services/analysisService.js
import api from './api';

const analysisService = {
  // Démarrer une nouvelle analyse de sécurité
  startAnalysis: async (repositoryId) => {
    try {
      const response = await api.post('/analysis/start', { repositoryId });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer une analyse spécifique
  getAnalysis: async (analysisId) => {
    try {
      const response = await api.get(`/analysis/${analysisId}`);
      return response.data.analysis;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer toutes les analyses d'un dépôt
  getRepositoryAnalyses: async (repoId) => {
    try {
      const response = await api.get(`/analysis/repository/${repoId}`);
      return response.data.analyses;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les dernières analyses de tous les dépôts
  getLatestAnalyses: async () => {
    try {
      const response = await api.get('/analysis');
      return response.data.analyses;
    } catch (error) {
      throw error;
    }
  },

  // Simuler une vérification périodique du statut de l'analyse
  pollAnalysisStatus: async (analysisId, callback, interval = 5000) => {
    const intervalId = setInterval(async () => {
      try {
        const analysis = await analysisService.getAnalysis(analysisId);
        
        callback(analysis);
        
        // Arrêter la vérification si l'analyse est terminée ou a échoué
        if (['completed', 'failed'].includes(analysis.status)) {
          clearInterval(intervalId);
        }
      } catch (error) {
        console.error('Erreur lors de la vérification du statut:', error);
        clearInterval(intervalId);
      }
    }, interval);
    
    // Retourner l'ID d'intervalle pour pouvoir l'arrêter manuellement
    return intervalId;
  }
};

export default analysisService;