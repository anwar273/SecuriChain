// src/services/authService.js
import api from './api';

const authService = {
  // Vérifier si l'utilisateur est authentifié
  verifyAuth: async () => {
    try {
      const response = await api.get('/auth/verify');
      return response.data.user;
    } catch (error) {
      throw error;
    }
  },

  // S'inscrire
  register: async (email, password) => {
    try {
      const response = await api.post('/auth/register', { email, password });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Se connecter
  login: async (email, password) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Ajouter un token GitHub
  addGithubToken: async (githubToken, userId) => {
    try {
      const response = await api.post('/auth/github-token', { githubToken, userId });
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default authService;