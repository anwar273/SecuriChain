// src/services/repositoryService.js
import api from './api';

const repositoryService = {
  // Récupérer tous les dépôts GitHub de l'utilisateur
  getRepositories: async () => {
    try {
      const response = await api.get('/repositories');
      return response.data.repositories;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les dépôts suivis par l'utilisateur
  getTrackedRepositories: async () => {
    try {
      const response = await api.get('/repositories/tracked');
      return response.data.repositories;
    } catch (error) {
      throw error;
    }
  },

  // Ajouter un dépôt au suivi
  trackRepository: async (repoData) => {
    try {
      const response = await api.post('/repositories/track', repoData);
      return response.data.repository;
    } catch (error) {
      throw error;
    }
  },

  // Récupérer les détails d'un dépôt suivi
  getRepositoryById: async (repoId) => {
    try {
      const response = await api.get(`/repositories/tracked/${repoId}`);
      return response.data.repository;
    } catch (error) {
      throw error;
    }
  }
};

export default repositoryService;