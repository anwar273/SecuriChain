// contexts/AuthContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);

  // Configure axios pour utiliser le token JWT
  useEffect(() => {
    if (token) {
      console.log("Configuration de l'en-tête Authorization");
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
      console.log("Suppression de l'en-tête Authorization");
      delete axios.defaults.headers.common['Authorization'];
    }
  }, [token]);

  // Vérifier l'authentification au chargement
  useEffect(() => {
    const checkAuth = async () => {
      const storedToken = localStorage.getItem('token');
      
      if (storedToken) {
        try {
          console.log("Vérification du token stocké");
          
          // Configurer temporairement le token pour cette requête
          axios.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
          
          // Vérifier si le token est valide
          const response = await axios.get('/api/auth/verify');
          console.log("Vérification réussie:", response.data);
          
          setCurrentUser(response.data.user);
          setToken(storedToken);
        } catch (error) {
          console.error("Erreur lors de la vérification du token:", error);
          
          // Token invalide, nettoyer
          localStorage.removeItem('token');
          delete axios.defaults.headers.common['Authorization'];
          setToken(null);
          setCurrentUser(null);
        }
      } else {
        console.log("Aucun token stocké");
      }
      
      setLoading(false);
    };
    
    checkAuth();
  }, []);

  // S'inscrire
  const register = async (email, password) => {
    try {
      console.log("Tentative d'inscription avec:", email);
      
      const response = await axios.post('/api/auth/register', { email, password });
      console.log("Inscription réussie:", response.data);
      
      const { token, user } = response.data;
      
      localStorage.setItem('token', token);
      setToken(token);
      setCurrentUser(user);
      
      return user;
    } catch (error) {
      console.error("Erreur d'inscription:", error);
      throw error;
    }
  };

  // Se connecter
  const login = async (email, password) => {
    try {
      console.log("Tentative de connexion avec:", email);
      
      const response = await axios.post('/api/auth/login', { email, password });
      console.log("Connexion réussie:", response.data);
      
      const { token, user } = response.data;
      
      localStorage.setItem('token', token);
      setToken(token);
      setCurrentUser(user);
      
      // Attendre un court instant pour garantir la mise à jour des états
      await new Promise(resolve => setTimeout(resolve, 100));
      
      return user;
    } catch (error) {
      console.error("Erreur de connexion:", error);
      throw error;
    }
  };

  // Se déconnecter
  const logout = () => {
    console.log("Déconnexion");
    localStorage.removeItem('token');
    setToken(null);
    setCurrentUser(null);
  };

  // Dans contexts/AuthContext.js - Fonction addGithubToken
// Dans contexts/AuthContext.js - Version simplifiée sans backend
const addGithubToken = async (githubToken) => {
  try {
    // Stocker localement le token GitHub pour continuer le développement
    localStorage.setItem('githubToken', githubToken);
    
    // Mettre à jour l'état utilisateur
    setCurrentUser(prev => ({
      ...prev,
      hasGithubToken: true
    }));
    
    return { message: 'Token GitHub stocké localement' };
  } catch (error) {
    console.error("Erreur lors du stockage local du token GitHub:", error);
    throw error;
  }
};
  const value = {
    currentUser,
    isAuthenticated: !!currentUser,
    loading,
    register,
    login,
    logout,
    addGithubToken
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}